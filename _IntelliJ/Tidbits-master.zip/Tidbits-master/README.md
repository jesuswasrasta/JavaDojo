#Tidbits

A place to put different things

##Contents

- resharper.jar : Keymapping for IDEA platforms based of of VS ReSharper keymappings
- sobkotlin.jar : Color scheme based off of Son of Obsidian for VS with support for Kotlin
- breaking_csharp: Some code we used in a Webinar with Jon Skeet showing how he can break ReSharper and C#

## Credits

Son of Obsidian Kotlin support is based off of the work of Roger located at 
http://www.aremaitchconsulting.com/2011/02/color-schemes-for-intellij-idea/
I added support for Kotlin and created a settings file for it.
